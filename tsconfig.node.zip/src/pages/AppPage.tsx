
import { useAccount } from "wagmi";
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ControlPanel } from "@/components/ControlPanel";
import { StakeDashboard } from "@/components/StakeDashboard";
import { LiveLogFeed } from "@/components/LiveLogFeed";
import { RobotCameraFeed } from "@/components/RobotCameraFeed";
import { RobotStatus } from "@/components/RobotStatus";
import { ChatSystem } from "@/components/ChatSystem";
import { StakingLeaderboard } from "@/components/StakingLeaderboard";
import { RobotLocationMap } from "@/components/RobotLocationMap";
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { useBlockchainUtils } from "@/lib/blockchainUtils";

const AppPage = () => {
  const { isConnected } = useAccount();
  const [searchParams, setSearchParams] = useSearchParams();
  const [location, setLocation] = useState(searchParams.get("location") || "Warehouse");
  const [coordinates, setCoordinates] = useState({ x: 0, y: 0 });
  const [selectedRobot, setSelectedRobot] = useState(searchParams.get("robot") || "robot-1");
  const blockchainUtils = useBlockchainUtils();
  
  useEffect(() => {
    // Update URL when robot changes
    if (searchParams.get("robot") !== selectedRobot) {
      setSelectedRobot(searchParams.get("robot") || "robot-1");
    }
  }, [searchParams, selectedRobot]);
  
  useEffect(() => {
    // When selectedRobot changes, update the URL
    setSearchParams({ robot: selectedRobot });
  }, [selectedRobot, setSearchParams]);
  
  const robots = [
    { id: "robot-1", name: "Warehouse Bot Alpha", chargeRate: 2.5 },
    { id: "robot-2", name: "Garden Maintenance Bot", chargeRate: 1.8 },
    { id: "robot-3", name: "Security Patrol Bot", chargeRate: 1.2 },
    { id: "robot-4", name: "Delivery Bot", chargeRate: 1.5 },
    { id: "robot-5", name: "Assembly Line Bot", chargeRate: 0.9 },
    { id: "robot-6", name: "Cleaning Bot", chargeRate: 0.8 },
  ];

  const selectedRobotData = robots.find(r => r.id === selectedRobot) || robots[0];

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <main className="flex-1 py-4 container px-4 animate-fade-in">
        {isConnected ? (
          <div className="grid grid-cols-12 gap-2">
            {/* Left Column */}
            <div className="col-span-12 lg:col-span-8 space-y-2">
              <RobotCameraFeed 
                robotId={selectedRobot}
                robotName={selectedRobotData.name} 
                viewerCount={5}
                chargeRate={selectedRobotData.chargeRate}
              />
              <ControlPanel />
              <RobotLocationMap coordinates={coordinates} location={location} />
            </div>
            
            {/* Right Column - Fixed layout to prevent overlapping */}
            <div className="col-span-12 lg:col-span-4 space-y-2">
              {/* Fixed height for ChatSystem */}
              <div className="h-[280px]">
                <ChatSystem />
              </div>
              {/* Dashboard with fixed height */}
              <div className="h-[140px]">
                <StakeDashboard />
              </div>
              <StakingLeaderboard
              robotId={selectedRobot} />
              <RobotStatus 
                batteryLevel={85}
                connectionStatus="Connected"
                lastActive="2023-11-08T14:30:00Z"
              />
            </div>
            
            {/* Full Width Bottom Panel */}
            <div className="col-span-12 mt-2">
              <LiveLogFeed />
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center p-10 bg-card rounded-lg border border-border shadow-lg animate-scale-in">
            <h2 className="text-2xl font-bold mb-4">Connect Your Wallet</h2>
            <p className="text-center max-w-md mb-6">
              Please connect your wallet to view the robot feed and control panel.
            </p>
            <div className="z-50 relative">
              <ConnectButton />
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default AppPage;
